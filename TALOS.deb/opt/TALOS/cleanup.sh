> logs/notify.log
> logs/rubberglue_log.txt
