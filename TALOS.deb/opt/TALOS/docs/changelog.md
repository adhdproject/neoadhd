-- 12/16 --
Added Changelog
Global bootstrap library added
Auto installation of requirements
Added archive folder
Added utilities folder
Added profile switcher utility
Added alias profiles conf/aliases.d/


