


class passthrough:
	

	qu = None
	killme = None
	
	def __init__(self, qu, killme):
		self.qu = qu
		self.killme = killme
		return

	
