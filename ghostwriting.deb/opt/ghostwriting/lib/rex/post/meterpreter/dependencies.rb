# -*- coding: binary -*-

require 'rex/post/permission'
