# -*- coding: binary -*-

module Rex
module ImageSource

end
end

require 'rex/image_source/disk'
require 'rex/image_source/memory'
