# -*- coding: binary -*-

module Rex

  module Poly

    require 'metasm'
    require 'rex/poly/machine/machine'
    require 'rex/poly/machine/x86'

  end

end
