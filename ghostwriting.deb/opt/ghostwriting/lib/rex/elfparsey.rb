# -*- coding: binary -*-

module Rex
module ElfParsey

end
end

require 'rex/elfparsey/elf'
