# -*- coding: binary -*-
require 'rex/platforms/windows'
