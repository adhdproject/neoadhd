# -*- coding: binary -*-
require 'rex/payloads/win32'
