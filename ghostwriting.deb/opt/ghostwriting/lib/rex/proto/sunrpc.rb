# -*- coding: binary -*-
require 'rex/proto/sunrpc/client'
