# encoding: binary

# SIP protocol support
require 'rex/proto/sip/response'
