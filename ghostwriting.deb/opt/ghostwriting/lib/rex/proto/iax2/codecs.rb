# -*- coding: binary -*-
require 'rex/proto/iax2/codecs/g711'
require 'rex/proto/iax2/codecs/mulaw'
require 'rex/proto/iax2/codecs/alaw'

