# -*- coding: binary -*-
require 'rex/proto/ntp/constants'
require 'rex/proto/ntp/modes'
