# -*- coding: binary -*-
require 'rex/proto/iax2/client'
