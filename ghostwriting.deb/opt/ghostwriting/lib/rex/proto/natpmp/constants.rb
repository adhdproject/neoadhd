# -*- coding: binary -*-
##
#
# NAT-PMP constants
#
# by Jon Hart <jhart@spoofed.org>
#
##

module Rex
module Proto
module NATPMP
  DefaultPort = 5351
  Version = 0
  TCP = 2
  UDP = 1
end
end
end
