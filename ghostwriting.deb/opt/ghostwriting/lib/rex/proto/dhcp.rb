# -*- coding: binary -*-
#
# DHCP Server support written by scriptjunkie
#

require 'rex/proto/dhcp/constants'
require 'rex/proto/dhcp/server'
