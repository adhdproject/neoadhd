# -*- coding: binary -*-
require 'rex/proto/dcerpc/wdscp/constants'
require 'rex/proto/dcerpc/wdscp/packet'
