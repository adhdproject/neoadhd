# -*- coding: binary -*-
require 'rex/registry/hive'
require 'rex/registry/regf'
require 'rex/registry/nodekey'
require 'rex/registry/lfkey'
require 'rex/registry/valuekey'
require 'rex/registry/valuelist'

module Rex
module Registry

  attr_accessor :alias
end
end
