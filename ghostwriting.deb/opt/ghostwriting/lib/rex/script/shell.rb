# -*- coding: binary -*-

module Rex
module Script
class Shell < Base

end
end
end

