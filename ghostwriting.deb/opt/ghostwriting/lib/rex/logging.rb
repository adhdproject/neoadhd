# -*- coding: binary -*-

require 'rex/constants' # for LEV_'s
require 'rex/logging/log_dispatcher'
