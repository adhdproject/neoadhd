# -*- coding: binary -*-

# just a shim to load all of the Struct2 libraries

require 'rex/struct2/c_struct_template'
