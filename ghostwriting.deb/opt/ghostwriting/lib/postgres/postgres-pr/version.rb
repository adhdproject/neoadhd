# -*- coding: binary -*-
# Namespace for Metasploit branch.
module Msf
module Db

module PostgresPR
  Version = "0.6.3-msf"
end

end
end
