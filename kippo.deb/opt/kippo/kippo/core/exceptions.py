# Copyright (c) 2009-2014 Upi Tamminen <desaster@gmail.com>
# See the COPYRIGHT file for more information

class NotEnabledException(Exception):
    """ Feature not enabled
    """

# vim: set sw=4 et:
