#!/usr/bin/env python

import sys
import os
import subprocess
import time

#Kind of important that you keep a good lock on the logfile.  It's gonna contain sensitive information for whatever user account you're targeting.

signatures = ["command not found","No command","did you mean","No such file or directory","Not a directory"]

if os.getuid() != 0:
        print "Please only run as root"
        print "I want good privilege seperation with these log files"
        exit(0)

if len(sys.argv) < 2:
	print "Human identification on service accounts"
	print "Proper Usage"
	print sys.argv[0] + " <username_to_monitor> "
	print "or"
	print sys.argv[0] + " <username_to_stop_monitoring> stop "
	exit(1)

user = sys.argv[1]

baselogpath = "/var/log/human/"
logfile = "%s%s" % (baselogpath, user)

def __build__():
	if not os.path.exists(baselogpath): 
		os.system("mkdir -p %s" % (baselogpath))
		os.system("chmod 711 %s" % (baselogpath))

def __exec__(com):
	p = subprocess.Popen(com, stdout=subprocess.PIPE, shell=True)
	out, err = p.communicate()
	return out

def gethome(user):
	home =  __exec__("awk 'BEGIN { FS=\":\" } ; /%s/ {print $6}' /etc/passwd" % (user))
	if home[-1] == "\n":
		home = home[:-1]
	if home[-1] != "/":
		home = home + "/"
	return home

def ismon(user):
	home = gethome(user)
	read = ""

	try:
		read = __exec__("grep 'exec 2> >(tee -a' %s.bashrc" % (home))
	except:
		print "No bashrc found, moving on."
		return False

	if len(read) < 3:
		return False
	else:
		return True

def start_mon(user):
	home = gethome(user)
	__exec__("touch %s " % (logfile))
	__exec__("mkdir -p %s && touch %s.bashrc" % (home, home))
	fi = open("%s.bashrc" % (home), "a")
	fi.write("exec 2> >(tee -a %s)" % (logfile))
	fi.close()
	__exec__("chmod 600 %s" % (logfile))

def stop_mon(user):
	home = gethome(user)
	
	__exec__("sed -i '/exec 2\>/c\ ' %s.bashrc" % (home))
	print "Stopped monitoring user %s" % user

def monitor_user(user):
	while True:
		out = __exec__("cat %s" % (logfile))
		for signature in signatures:
			if signature in out:
				print "Alert <%s> is acting like a human" % (user)
				__exec__("> %s" % (logfile))
		time.sleep(10)

if __name__ == "__main__":
	if len(sys.argv) == 2 or (len(sys.argv) > 2 and sys.argv[2] != "stop"):
		print "Starting mon service"
		print "NO ALERT SERVICE ATTACHED"
		print "ALERTS WILL BE PIPED TO STDOUT"
	__build__()
	if not ismon(user):
		start_mon(user)
	if len(sys.argv) > 2 and sys.argv[2]  == "stop":
		stop_mon(user)
		exit(0)

	monitor_user(user)


	
