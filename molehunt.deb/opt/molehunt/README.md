#Molehunt

Check out the comments in `molehunt.py`.  There are a few variables that
you will need to set before the script will work.

The script relies on a few external technolgies.
It needs a generator.
At this time, the supported generators are:

* docz.py

It also needs a collection service.
At this time the supported collectors are:

* webbugserver
* sqlitebugserver
* honeybadger

The comments in `molehunt.py` can tell you more about how to configure
molehunt to work with these technologies.

I will be updating this tool and adding more features when I have time.

If you have any questions you can contact me on Twitter [@zaeyx](https://twitter.com/zaeyx)
