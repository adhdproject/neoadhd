#NOTICE

This project has not yet completed an open code review process.

Though it may very well be safe, it has not been shown to be at this time.

I am working on reviewing it myself, as well as finding others to help me review it.

Cryptography is very hard, and even the slightest error in my code may leave this algorithm vulnerable to attack.  That being said, it's still almost certainly safer than what you're using right now (because you can use adaptive hashing in concert with the generation process).

Please let me know if you find anything wrong with my code and I'll fix it.

[@zaeyx](https://twitter.com/zaeyx)
