echo "Updating library to latest version..."
echo "*************************************"
git pull origin master
