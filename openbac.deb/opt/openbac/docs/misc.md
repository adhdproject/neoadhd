#MISC

The misc folder contains miscellaneous files important to the utilities.

Specifically, it contains the certificates for server.py.

And is a great place to put your arrayfile during testing.
