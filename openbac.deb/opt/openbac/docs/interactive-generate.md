#Interactive-Generate

###Description
The interactive generation script is used to create a new array file.

###Usage

It's incredibly easy to use.  Simply follow the prompts presented to you.

You'll want to pick a pointerlength that gives you a file large enough for your situation.

Once you're done running the script you will need to update the pointerlengths variable in the config file (openbac.conf).  This will make sure that the server can function correctly.

It is not necessary to update the config file if you are using the library directly (openbac.py) as you will specify all settings in your method calls.


