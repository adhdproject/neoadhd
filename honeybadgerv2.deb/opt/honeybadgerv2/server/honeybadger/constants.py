ROLES = {
    0: 'admin',
    1: 'analyst',
}

STATUSES = {
    0: 'initialized',
    1: 'active',
    2: 'inactive',
    3: 'reset',
}

class COLORS(object):
    N = '\033[m' # native
    R = '\033[31m' # red
    G = '\033[32m' # green
    O = '\033[33m' # orange
    B = '\033[34m' # blue
